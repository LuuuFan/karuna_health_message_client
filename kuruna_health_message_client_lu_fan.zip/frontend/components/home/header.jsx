import React from 'react';

const Header = () => (
	<header>
		<h1>
			Karuna Health Message Client
		</h1>
	</header>
);

export default Header;
// APIUtil for recevie new message and send message, can use webSocket

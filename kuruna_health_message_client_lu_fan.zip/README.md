![alt text](https://raw.githubusercontent.com/LuuuFan/karuna_health_message_client/master/public/images/favicon.ico "logo")
# Karuna Health Message Client

Online Preview: [Link](https://luuufan.github.io/karuna_health_message_client/#/)

How to run on local:

```
	npm install
	python -m SimpleHTTPServer 3000
```
then open browerser to visit: http://localhost:3000/

![alt text](https://github.com/LuuuFan/karuna_health_message_client/blob/master/public/images/Screen%20Shot%202019-09-22%20at%209.00.08%20PM.png "screenshot")
